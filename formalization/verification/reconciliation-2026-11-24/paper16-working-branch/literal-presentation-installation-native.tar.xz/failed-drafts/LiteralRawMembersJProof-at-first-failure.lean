module

public import LogicLineages.PersistentMarking.NumberedWindowInternalLiteralJCompleteProof
public import LogicLineages.PersistentMarking.NumberedWindowInternalDirectTypedListOpenProof
public import LogicLineages.PersistentMarking.NumberedWindowInternalCoordinateChecks
import LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.InternalComputabilityApplicationSyntaxProof
import LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.InternalSourceIntroductionSyntaxProof
import LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.InternalGraphCompositionFunctionalityProof

@[expose] public section
namespace LogicLineages.PersistentMarking.NumberedWindowInternalLiteralRawMembersJProof
open FirstOrder Language LogicLineages.OrdinalComparison.TerminationOrdering
open PositiveArithmeticOperators SourceComputabilityFormulaSupportProof
open LogicLineages.ComputabilityKnowledge.GorbowPRProgram (Program)
open ID1Completion.InternalCalculus ID1Completion.InternalControlGraph
open ID1Completion.InternalGraphComposition (OTerm)
open ID1Completion.InternalAccessibilityRules (carrier membership)
open ID1Completion.InternalAccessibilityRulesSyntaxProof (membershipRename)
open ID1Completion.InternalTagArithmeticSyntaxProof
  (emb sucSubst zSubst bindEmbedding liftBind varBind)
open ID1Completion.InternalComputabilityApplicationSyntaxProof
  (programSubst allEmbeddedSubst liftTermSubst)
open ID1Completion.InternalSourceIntroductionSyntaxProof
  (formulaRelabelAsSubst termRelabelAsSubst)
open ID1Completion.InternalGraphCompositionFunctionalityProof (renameInto)
open ID1Completion.SourcePresentation (sourceBody)
open NumberedWindowTypeFormulaSubstitutionProof (impSubst)
open NumberedWindowInternalDirectTypedUnionLiteralJTargets (literalData)
open NumberedWindowInternalDirectTypedListTargets (jRaw)
open NumberedWindowInternalDirectTypedListOpenProof (exact_OpenJRaw)
open NumberedWindowInternalDirectCoreTargets (dCore)
open NumberedWindowInternalLiteralCount (permutation)
open NumberedWindowInternalCoordinateChecks (exact_DomainRules)
open NumberedWindowInternalCertifiedUnionStepProof (Pr)
open NumberedWindowInternalLiteralSparseJFoldSyntaxProof (scalarMembers scalarMembersSubst)
open NumberedWindowInternalSparseFieldParser (parser)
open NumberedWindowInternalSparsePathEnvelopeTargets (unary suc z)

/-- Every scalar in the actual positively decoded raw multiset is in I.
The literal-carrier premise of the theorem supplies a genuine parser
success, so this formula is not used vacuously on malformed codes. -/
def allRawMembers {α : Type} (raw : OTerm α) : Formula α :=
  let scratch : OTerm (α ⊕ Fin 1) := .var (.inr 0)
  allOne ((unary parser (suc scratch) (raw.relabel Sum.inl)).imp (scalarMembers scratch))

private theorem unaryAtSubst {α β : Type} (p : Program 1) (o x : OTerm α) (ts : α → OTerm β) :
    (unary p o x).subst (fun k => emb (ts k)) = unary p (o.subst ts) (x.subst ts) := by
  unfold unary
  rw [programSubst]
  congr 1
  funext k
  obtain rfl := Fin.eq_zero k
  rfl

private theorem allRawMembersSubst {α β : Type} (raw : OTerm α) (ts : α → OTerm β) :
    (allRawMembers raw).subst (fun k => emb (ts k)) = allRawMembers (raw.subst ts) := by
  simp only [allRawMembers,allEmbeddedSubst,impSubst,unaryAtSubst,sucSubst,
    scalarMembersSubst,liftTermSubst] <;> rfl

private theorem allRawMembersRename {α β : Type} (raw : OTerm α) (j : α → β) :
    (allRawMembers raw).relabel j = allRawMembers (raw.relabel j) := by
  rw [formulaRelabelAsSubst]
  change (allRawMembers raw).subst (fun k => emb (.var (j k))) = _
  rw [allRawMembersSubst,← termRelabelAsSubst]

private theorem instanceAt {α : Type} (raw scratch : OTerm α) :
    instantiate ((unary parser (suc (.var (.inr (0 : Fin 1)))) (raw.relabel Sum.inl)).imp
      (scalarMembers (.var (.inr (0 : Fin 1))))) (emb scratch) =
        ((unary parser (suc scratch) raw).imp (scalarMembers scratch)) := by
  simp only [instantiate,bindEmbedding,impSubst,unaryAtSubst,sucSubst,
    scalarMembersSubst,liftBind,varBind]

/-- Actual raw-code member introduction: a held J-carrier and I for all
members of its successful literal parse imply J in the same installed
body. No scratch decoder witness, typed fold, split or arithmetic
premise is supplied by the caller. -/
theorem exact_LiteralRawMembersJ (i : Program 1) (r : Program 3) (c : Nat)
    (α : Type) (Γ : List (Formula α)) (raw : OTerm α)
    (typed : Pr (literalData i r) c Γ (carrier (literalData i r) true c raw))
    (available : Pr (literalData i r) c Γ (allRawMembers raw)) :
    Pr (literalData i r) c Γ (membership true raw) := by
  let S := literalData i r
  let B := sourceBody S c
  have opened : Nonempty (Derivation B Γ (unary (jRaw i) (suc z) raw)) :=
    (exact_DomainRules i (jRaw i) r (dCore i r permutation) true c B α Γ raw).1 typed
  apply exact_OpenJRaw i B α Γ raw _ opened
  intro β j Δ scratch keep reports
  rw [membershipRename]
  obtain ⟨all⟩ := renameInto available j Δ keep
  rw [allRawMembersRename,allRawMembers] at all
  have rule := Derivation.universalElimination (emb scratch) all
  rw [instanceAt] at rule
  obtain ⟨decoded⟩ := reports.parsed
  exact NumberedWindowInternalLiteralJCompleteProof.exact_LiteralParsedJ i r c β Δ
    (raw.relabel j) scratch ⟨decoded⟩ reports.typed ⟨Derivation.implicationElimination rule decoded⟩

#print axioms exact_LiteralRawMembersJ
end LogicLineages.PersistentMarking.NumberedWindowInternalLiteralRawMembersJProof
