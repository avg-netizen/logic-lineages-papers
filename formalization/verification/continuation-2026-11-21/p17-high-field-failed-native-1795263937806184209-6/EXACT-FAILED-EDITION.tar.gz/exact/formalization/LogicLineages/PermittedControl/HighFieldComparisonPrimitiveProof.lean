module
public import LogicLineages.PermittedControl.HighFieldComparisonTargets
import LogicLineages.PermittedControl.ShortFieldEffectivityProof
import LogicLineages.PermittedControl.LongFieldTailPrimitiveProof
import LogicLineages.PermittedControl.RawFieldComparisonFormPrimitiveProof
import LogicLineages.PermittedControl.ThresholdNumericProgramsProof

@[expose] public section
namespace LogicLineages.PermittedControl.FieldComparison
open OrdinalComparison

private theorem normalize_code_if (P : LongFieldCode) :
    normalizeHighFieldCode P =
      if P.1 = 0 then P else
        let k := shortIterateCode P.2.2.1 P.2.2.2 P.2.1
        if k = 0 then P else (0,k - 1,0,0) := by
  rcases P with ⟨tag,a,lam,mu⟩
  by_cases h : tag = 0
  · simp [normalizeHighFieldCode,h]
  · cases hk : shortIterateCode lam mu a <;>
      simp [normalizeHighFieldCode,h,hk]

private theorem normalizeHighFieldCode_primrec : Primrec normalizeHighFieldCode := by
  have ht : Primrec (fun p : LongFieldCode => p.1) := Primrec.fst
  have ha : Primrec (fun p : LongFieldCode => p.2.1) := Primrec.fst.comp Primrec.snd
  have hl : Primrec (fun p : LongFieldCode => p.2.2.1) := Primrec.fst.comp (Primrec.snd.comp Primrec.snd)
  have hm : Primrec (fun p : LongFieldCode => p.2.2.2) := Primrec.snd.comp (Primrec.snd.comp Primrec.snd)
  have hk := shortFieldPreprocessingEffective.2.2.1.comp (hl.pair (hm.pair ha))
  have hz : Primrec (fun _ : LongFieldCode => (0 : Nat)) := Primrec.const 0
  have hnew := hz.pair ((Primrec.nat_sub.comp hk (Primrec.const 1)).pair (hz.pair hz))
  exact (Primrec.ite (Primrec.eq.comp ht hz) Primrec.id
    (Primrec.ite (Primrec.eq.comp hk hz) Primrec.id hnew)).of_eq
    (fun p => (normalize_code_if p).symm)

private theorem highShortBoundCode_primrec : Primrec₂ highShortBoundCode := by
  have hB : Primrec (fun p : Nat × LongFieldCode => p.1) := Primrec.fst
  have ht : Primrec (fun p : Nat × LongFieldCode => p.2.1) := Primrec.fst.comp Primrec.snd
  have hl : Primrec (fun p : Nat × LongFieldCode => p.2.2.2.1) :=
    Primrec.fst.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
  have hm : Primrec (fun p : Nat × LongFieldCode => p.2.2.2.2) :=
    Primrec.snd.comp (Primrec.snd.comp (Primrec.snd.comp Primrec.snd))
  exact Primrec.ite (Primrec.eq.comp ht (Primrec.const 0)) (Primrec.const 0)
    (shortFieldPreprocessingEffective.2.2.2.1.comp (hl.pair (hm.pair hB)))

private theorem highFieldComparisonBoundCode_primrec :
    Primrec (fun p : Nat × LongFieldCode × LongFieldCode =>
      highFieldComparisonBoundCode p.1 p.2.1 p.2.2) := by
  have hB : Primrec (fun p : Nat × LongFieldCode × LongFieldCode => p.1) := Primrec.fst
  have hP : Primrec (fun p : Nat × LongFieldCode × LongFieldCode => p.2.1) :=
    Primrec.fst.comp Primrec.snd
  have hQ : Primrec (fun p : Nat × LongFieldCode × LongFieldCode => p.2.2) :=
    Primrec.snd.comp Primrec.snd
  have hNP := normalizeHighFieldCode_primrec.comp hP
  have hNQ := normalizeHighFieldCode_primrec.comp hQ
  have hPQ := hB.pair (hNP.pair hNQ)
  have hQP := hB.pair (hNQ.pair hNP)
  exact Primrec.nat_max.comp
    (Primrec.nat_max.comp (highShortBoundCode_primrec.comp hB hP) (highShortBoundCode_primrec.comp hB hQ))
    (Primrec.nat_max.comp (longFieldSameBoundCode_primrec.comp hPQ)
      (Primrec.nat_max.comp (longFieldDistinctBoundCode_primrec.comp hPQ)
        (longFieldDistinctBoundCode_primrec.comp hQP)))

private theorem flipHighComparisonAnswer_primrec : Primrec₂ flipHighComparisonAnswer := by
  exact Primrec.ite (Primrec.eq.comp Primrec.fst (Primrec.const 0)) Primrec.snd
    (reverseComparisonCode_primrec.comp Primrec.snd)

private theorem rawConstForm_primrec : Primrec rawConstForm :=
  (Primrec.const 0).pair (Primrec.id.pair (Primrec.const (0,0,0,0)))

private theorem highRawComparisonForm_primrec :
    Primrec (fun p : LongFieldCode × LongFieldCode × Nat × Nat =>
      highRawComparisonForm p.1 p.2.1 p.2.2.1 p.2.2.2) := by
  have hP : Primrec (fun p : LongFieldCode × LongFieldCode × Nat × Nat => p.1) := Primrec.fst
  have hQ : Primrec (fun p : LongFieldCode × LongFieldCode × Nat × Nat => p.2.1) :=
    Primrec.fst.comp Primrec.snd
  have hx : Primrec (fun p : LongFieldCode × LongFieldCode × Nat × Nat => p.2.2.1) :=
    Primrec.fst.comp (Primrec.snd.comp Primrec.snd)
  have hy : Primrec (fun p : LongFieldCode × LongFieldCode × Nat × Nat => p.2.2.2) :=
    Primrec.snd.comp (Primrec.snd.comp Primrec.snd)
  have hNP := normalizeHighFieldCode_primrec.comp hP
  have hNQ := normalizeHighFieldCode_primrec.comp hQ
  exact Primrec.ite (Primrec.nat_lt.comp hx hy)
    ((Primrec.const 0).pair (rawFieldComparisonFormEffective.1.comp hNP hNQ))
    (Primrec.ite (Primrec.nat_lt.comp hy hx)
      ((Primrec.const 1).pair (rawFieldComparisonFormEffective.1.comp hNQ hNP))
      ((Primrec.const 0).pair (rawConstForm_primrec.comp (rawFieldComparisonFormEffective.2.comp hNP hNQ))))

theorem highFieldComparisonEffective : HighFieldComparisonEffective :=
  ⟨normalizeHighFieldCode_primrec,highShortBoundCode_primrec,highFieldComparisonBoundCode_primrec,
    flipHighComparisonAnswer_primrec,highRawComparisonForm_primrec⟩

end LogicLineages.PermittedControl.FieldComparison
