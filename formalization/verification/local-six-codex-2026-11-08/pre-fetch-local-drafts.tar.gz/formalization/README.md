## Current continuation — 7 November 2026

**Correction, 8 November 2026 UTC:** the user did not request Claude in current
lanes. The historical workflow was resumed by a coordinator misinterpretation.
Claude author admission is now disabled; current work is Codex-only under the
[current correction](CURRENT-2026-11-08-CODEX-ONLY.md). The November7 account below
is superseded. No R031 author result has returned.

The user resumed the existing single Sol 6.1 supervisor subagent with the same
Claude session from the post-R030 checkpoint below. Read the
[current scope and runtime release](RESUME-2026-11-07-ONE-LANE.md). The next
arithmetic/beta-trace supplier must pass frozen target, compiler and exact
axiom checks. Other lanes remain paused; no new publication is authorized.

## Previous local checkpoint — paused after R030, 5 November 2026 UTC

The single Sol 6.1 supervisor subagent and same-session Claude have finished
R030 and paused. One new supporting component proves three universally
quantified PA addition laws in the existing calculus over arbitrary additional
closed theories: associativity, commutativity, and `x + y = 0 → x = 0`.
The three individual aliases and their conjunction passed the frozen exact
gate and actual axiom audits, using only `propext` and `Quot.sound`. The raw
candidate passed its first compile unchanged; no repairs were needed.

The full R029 primitive-recursion certificate target remains pending: its
author returned no proof module. No whole numbered statement is promoted;
the register stays **161 checked, 2 inherited, 26 pending/189**. All owned jobs
are reaped, successor admission is disabled, and the compiler policy is paused.
No full-root rebuild or remote-CI pass is claimed. Read the
[final handoff](HANDOFF-2026-11-04-ONE-LANE-PAUSED.md) and
[exact acceptance evidence](verification/local-resume-2026-11-04-one-lane/claude/R030-ACCEPTANCE.json).
The user authorized pushing this paused public checkpoint on
`formalization/reconcile-unpublished-2026-11-04`.

---

## Previous cumulative checkpoint — 5 November 2026

Actual source-term graphs and general source-to-quantified-row introduction
add **sixteen checked exact supporting targets in four gates**. The cumulative
branch now contains **24 exact supporting targets in six gates**, including
the preceding normal-form row/domain/compiler package.

Every original source formula has an equivalent concrete quantified-row
translation under every valuation. The translation preserves exact free-variable
membership, repeated occurrences, original binder names and ordinary shadowing.
It binds each atom's introduced witnesses locally and retains original Boolean
positions. The exact numeric source compiler is primitive recursive.

The focused aggregate `LogicLineages.ExternalCheckpoint20261105SourceIntroduction`
passed. All **133 local modules** in its import closure have successful native
receipts matching their current hashes. All sixteen new exact aliases passed
their standard-axiom audits. Definitions and target types remain at their
successful pre-authoring preflight hashes.

The numbered source register remains **161 checked, 2 inherited, 26 pending
out of 189**. Full single-prefix existential normal form, quantified-block
elimination and arbitrary first-order BASE decision remain pending. The focused
gate does not claim a full public-root rebuild or remote-CI pass.

Read the [current checkpoint](verification/cumulative-continuation-2026-11-04/source-rows/STATUS.md),
[source correspondence](verification/cumulative-continuation-2026-11-04/source-rows/SOURCE-CORRESPONDENCE.md),
[term-graph evidence](verification/cumulative-continuation-2026-11-04/source-term-graph/ACCEPTANCE.json)
and [source-introduction evidence](verification/cumulative-continuation-2026-11-04/source-rows/ACCEPTANCE.json).
The branch remains `formalization/cumulative-continuation-2026-11-04` and
continues the accepted `eb0dd98` checkpoint. Earlier dated states below are
historical.

---

## Previous cumulative checkpoint — 4 November 2026

The Snyatkov normal-form row, domain and numeric-compiler package now has
**eight checked exact supporting targets in two gates**. The focused aggregate
`LogicLineages.ExternalCheckpoint20261104NormalForm` passed, and all 110 local
modules in its import closure have successful compiler receipts matching their
current source hashes. Every target passed its actual standard-axiom audit.
The frozen definitions and comparison types are unchanged.

The numbered source register remains **161 checked, 2 inherited, 26 pending
out of 189**. Full source existential normalization and arbitrary first-order
BASE decision remain pending. No full public-root or remote-CI pass is claimed.

Read the [checkpoint](verification/cumulative-continuation-2026-11-04/normal-form/STATUS.md),
[source correspondence](verification/cumulative-continuation-2026-11-04/normal-form/SOURCE-CORRESPONDENCE.md)
and [acceptance evidence](verification/cumulative-continuation-2026-11-04/normal-form/ACCEPTANCE.json).
The cumulative branch is `formalization/cumulative-continuation-2026-11-04`,
based on merged main `ba2dec0`. Earlier dated states below are historical.

---

Current local state: **PAUSED after completed R026 and all independent work**,
4 November 2026. This restart accepted **10 supporting components / 52 exact
declarations in 42 Lean files**. The focused integration and actual axiom checks
passed; the numbered source register remains **154 checked, 2 inherited,
33 pending/189**. Read [the current handoff](HANDOFF-2026-11-04-SECOND.md) and
[verification](verification/local-publication-2026-11-04-second/INTEGRATION.json).
All author/compiler jobs are reaped and successor/pause guards are sealed.
The user authorized publication only after this pause. No new research, quota
reset restart, independent lane, main-branch merge or CI change is authorized.
Older active allocations below are historical and do not resume any worker.

Earlier cumulative checkpoint: **the complete original contextual numeric step
checker is primitive recursive jointly in its binder context**. The original
quotient-edge and positive-path certificate tests are primitive recursive at
each fixed ambient context, retaining the actual representative computation.
On `formalization/cumulative-continuation-2026-11-03`, this continuation from
`9dc3473` adds **27 fixed targets in 7 supporting components**, bringing the
branch checkpoint to **46 fixed targets in 13 components**. All exact gates and
the focused aggregate passed with only the permitted axioms. See the
[contextual status and precise parameter scope](verification/cumulative-continuation-2026-11-03/contextual-checking/STATUS.md),
[accepted evidence](verification/cumulative-continuation-2026-11-03/contextual-checking/CONTEXTUAL-EFFECTIVITY-ACCEPTED.json),
and [prior root-checker checkpoint](verification/cumulative-continuation-2026-11-03/STATUS.md).

Exact calibrations preserve the original decoders, unguarded selector at
`focus.holeGamma`, focus/plug operations, outer step guards, quotient
representatives and ordered path certificates. `positivePathTest` rejects an
empty path even when its endpoints coincide. The source register remains
**154 checked, 2 inherited, 33 pending/189**, with **seven new primary links and
seven reuse links** recorded in the
[dependency progress](verification/cumulative-continuation-2026-11-03/contextual-checking/SOURCE-REGISTER-PROGRESS.json).
The [frozen specifications](verification/cumulative-continuation-2026-11-03/contextual-checking/CONTEXTUAL-EFFECTIVITY-FREEZE.json)
and [verified source closure](verification/cumulative-continuation-2026-11-03/contextual-checking/SOURCE-CLOSURE.json)
preserve the accepted scope. Genuine arithmetic graph formulas, source-required
parameter interfaces, whole-source assembly and internal ID1 accessibility
remain separate obligations; the
[next arithmetic bridge](verification/cumulative-continuation-2026-11-03/contextual-checking/NEXT-ARITHMETIC-BRIDGE.md)
states that boundary. The dated paragraphs below retain their historical scope.

Previous local state: **PAUSED after completed R021 and both independent lanes**,
4 November 2026. The final author/review/check cycle passed. This restart adds
20 supporting components/106 checked declarations; the whole-source register
remains154checked+2inherited+33pending/189. Read [the final handoff](HANDOFF-2026-11-04.md)
and [publication integration evidence](verification/local-publication-2026-11-04/INTEGRATION.json).
All workers and author/compiler guards remain paused. The latest user authorized
publication of this papers checkpoint, not a research restart or main-branch merge.
Older active/wind-down paragraphs below are historical.

Local formalization **resumed by the user on 3 November 2026**, after fetching
and fast-forwarding to GitHub main `98f5f56`. Three Codex lanes are active,
one managing the same Claude session with compile-first constructive repairs.
Read [the current allocation](RESUME-2026-11-03-LOCAL.md). Historical pause
records below remain evidence of their completed checkpoints.

Latest checked external continuation, **3 November 2026**: the existing
`formalization/external-continuation-2026-11-03` branch now proves primitive
recursion of the original exchange test, primary-class membership test,
least-code representative and canonical-carrier test. The computations are
joint in both windows and their packed or numeric inputs at each fixed finite
signature, arity and binder context. Exact list-saturation and bounded-search
calibrations retain the existing algorithms on arbitrary windows and inputs.
Thirteen new fixed targets passed their focused aggregate and axiom audit,
bringing this continuation to **374 fixed targets in 111 components**. See the
[current status](verification/external-continuation-2026-11-03/STATUS.md) and
[primary-class effectivity evidence](verification/external-continuation-2026-11-03/termination-ordering/PRIMARY-CLASS-PRIMREC-ACCEPTED.json).

The source-statement register remains **154 checked, 2 inherited, 33 pending/189**.
These totals count complete numbered source statements; the component count
records supporting results and source diagnostics. All 111 continuation
components have explicit source destinations. The latest
[dependency progress record](verification/external-continuation-2026-11-03/termination-ordering/PRIMARY-CLASS-PROGRESS.json)
closes the recorded exchange/primary-class/least-representative computation
dependency and updates the outstanding obligations. The original-source
numeric codec and translation, full numeric certificate checking, arithmetic
representation and internal ID1 accessibility remain open. The local pause
records and older releases below are historical.

Previous local checkpoint: **PAUSED**,3November2026UTC. **154 checked,2 inherited,33 pending/189**. Read [the final handoff](HANDOFF-2026-11-03.md), including the checked local transitivity source issue.

Current external round: **active through 1 November 2026, 17:00 UTC** (noon
UTC−05:00), on `formalization/external-continuation-2026-11-01`. Its current register is
135 checked, 2 inherited and 52 pending source statements. Follow
[the current continuation report](EXTERNAL-CONTINUATION-2026-11-01.md). The local
pause snapshot below is historical and has been superseded by this external release.

Current local checkpoint: **paused after the completed rounds, 1 November 2026 UTC**. The register has **134 checked, 2 inherited and 53 pending statements out of 189**. Read [the complete handoff](HANDOFF-2026-11-01.md); the older releases below are historical.

Local formalization was explicitly resumed on31October2026 from5cff59d. See [AGENTS.md](AGENTS.md) for current allocation; the old cutoff below is historical.

Local workers paused at the user-requested 10 p.m. America/Chicago cutoff (30 October 2026 03:00 UTC). No automatic local resume. Separately authorized external work and fresh-clone builds remain possible.

# Formalizing the public papers

Current external continuation: [31 October repair-aware round](EXTERNAL-CONTINUATION-2026-10-31.md). Its accepted baseline is the [30 October handoff](HANDOFF-2026-10-30.md), with [cumulative evidence](EXTERNAL-CONTINUATION-2026-10-30.md). Earlier pause/checkpoint and lane-status records below remain historical snapshots.

Local workers were **explicitly resumed by the user on 29 October 2026** after
the external continuation. Two independent Codex lanes, a Codex-led Claude loop
and main continue from [the external checkpoint](EXTERNAL-CONTINUATION.md).
Older pause records are historical. This is an
incomplete formalization programme for all fifteen papers in this repository.
The [target register](TARGETS.json) records 189 numbered
theorem/lemma/proposition/corollary statements from the full TeX input closure,
plus algorithmic and cited-supplier obligations. The [source snapshot](MANUSCRIPT-SNAPSHOT.json)
pins the current manuscript/build-source files read by that inventory. A count is
not a proof-coverage claim.

The calculator's existing checked development is a baseline dependency. Other
papers are not considered formalized merely because their definitions or an
intermediate lemma compile. Every full target remains pending until its actual
statement and complete dependency chain are checked.

## External continuation

See [the external continuation checkpoint](EXTERNAL-CONTINUATION.md) for new
accepted results, precise coverage and verification limits. Historical local
pause records remain preserved; this is a separately authorized continuation.

## Acceptance rule

1. Codex writes the exact mathematical semantics and comparison statement,
   checks their correspondence with the source, compiles them and freezes
   their hashes before Claude authors proof steps.
2. Claude's candidate proof source is separate from the frozen comparator.
   A candidate cannot edit that comparator, add missing suppliers as premises,
   or prove a surrogate model instead.
3. Compile first. Repair compiler errors or statement mismatches. A clean build
   proceeds to the exact type gate and actual axiom-closure check; it does not
   routinely receive a second hand proof audit.
4. The gate must check the candidate at the fixed type. Accepted proof closures
   may contain only the ordinary `propext`, `Classical.choice` and `Quot.sound`
   foundations. No `sorry`, `admit`, added axiom, `native_decide`, or assumed
   correctness/typeclass supplier is permitted.

A theorem's genuine hypotheses remain hypotheses: for example the ultrafilter
theorem assumes an idempotent ultrafilter near zero, exactly as in the paper.
That is different from assuming the witness or theorem which the paper proves.
Cited theorems absent from Mathlib are formalization work, even when they were
legitimate bibliographic dependencies in the prose paper.

## Work streams

| Stream | Papers | Owned modules |
|---|---|---|
| Ordinal/comparison lane | 04–10 | `LogicLineages/OrdinalComparison/` |
| Model theory and algebra lane | 01, 15 | `LogicLineages/ModelsAlgebra/PGroups/`, `Differential/` |
| Codex-led Claude loop | 02, 12, 14 | `LogicLineages/ComputabilityKnowledge/` |
| Main research and integration | 03; completed 11/13; package and shared gates | `LogicLineages/ModelsAlgebra/Forests/`, `Ultrafilters/`, `RL/` |

The [status directory](status/) contains each stream's concrete proof-to-paper
map. This programme does not resume unrelated mathematical research.

## Pinned libraries and compilation

The package uses Lean `v4.32.0-rc1`, Mathlib commit
`360da6fa66c1273b76b6b2d8c5666fd5ac2e3b56`, and the calculator package included
at `../04-pure-r1-calculator/lean`. No private repository is a public source
dependency. Standard setup with Lake is:

```sh
lake update
lake exe cache get
lake build +LogicLineages
```

The committed manifest pins dependencies. On this shared research machine,
use the bounded runner instead of starting independent Lake builds:

```sh
python3 scripts/check.py LogicLineages.RL.StatementChecks
```

The runner uses the pinned dependency cache already present in this package
or in the included calculator's development checkout. It never downloads or
rebuilds upstream libraries. Local development may borrow previously compiled
calculator objects; receipts report that choice. `--fresh` recompiles the
included local dependency closure, including calculator source, when resources
permit. Fresh source compilation is distinct from borrowing those objects.

All workers share a nonblocking lock with the existing calculator helper.
Both helpers use `/tmp` for their shared lock files by default. In a sandbox
without that directory, set `LEAN_CHECK_LOCK_DIR` to one existing absolute
directory shared by every paper and calculator compiler invocation. Relative,
missing, and non-directory paths are rejected before compilation. Keep the
same directory throughout an active compiler session; the two lock filenames
and all resource limits remain unchanged.

The default compiler has one thread, a 1,536 MiB managed-heap allowance,
an independently monitored 1,024 MiB process-tree resident-memory cap,
90-second CPU and 180-second wall bounds, and a system-free-memory guard. Increasing the
managed allowance does not remove the physical-memory limit. The initial
768 MiB managed budget caused library-load exhaustion; a controlled standard
order import passed at about 836 MiB RSS with the revised allowance.
The later import diagnosis distinguished Lean's legacy private-import mode
from its modern exported-module mode. New project files use `module`, public
imports and exposed public declarations, avoiding unnecessary private payloads.
The longer wall allowance covers observed import waits with little CPU use;
the CPU and physical-memory limits remain separate and unchanged. A compiler
does not start below 1 GiB available memory.
No large ordinal or fast-growing numerical value is evaluated to prove
symbolic statements.

For a verified `Init`/`Lean`/`Std`-only local import closure,
`--core-profile` instead requires 768 MiB available and imposes a tighter
512 MiB process-tree RSS cap. It rejects any Mathlib or calculator import
before launching. The 256 MiB system floor, CPU limit and source/axiom checks
remain in force. A fresh bounded-multiplication source closure passed this
profile with peak RSS below 393 MiB; the Mathlib-import rejection was checked
separately. This profile does not relax the default Mathlib build guards.

Each invocation prints a unique JSON receipt path under ignored
`build-reports/`, with source hashes, results, time and peak observed RSS.
Log filenames are unique to the invocation, so later repairs preserve the
original diagnostics. A resource stop also records every compiler thread's
wait state. A measured blocked page-I/O wait is distinct from proof search;
an explicitly longer wall-only allowance does not increase the CPU or RSS cap.
Resource stops and compiler errors are not mathematical refutations and
must not be reported as accepted proofs. `LogicLineages/Audit.lean` supplies
`#audit_namespace` to inspect the transitive axioms of every theorem in a
project namespace. Fixed statement gates remain a separate requirement.

The [component workflow](../.github/workflows/paper-components-lean.yml)
compiles each accepted gate from fresh local sources and preserves receipts.
Its title and summary explicitly limit certification to those components.
Its GitHub run and artifacts record the result for the exact checked revision.

## Reuse and full dependencies

The included calculator already reconstructs the pure single-relation R1
semantics and sharp norm bounds. It is suitable for checked notation/norm
reuse. Its relation must not be confused with the simultaneous order-two
relations in older Carlson developments.

The earlier 3.1.3 project contains useful first-order syntax, proof-checking,
arithmetization and ordinal modules. A matching name is insufficient for
reuse. For example, an earlier `FiniteCollapse` is a different mathematical
construction from the norm-controlled numerical collapse in these papers.
Gorbow's DCB/FS/KT and its self-indexed provability are also different from
the knowing-machine theory in that project. Any selected source reuse must
bring a complete local import closure, attribution, source hashes and its
actual statement/axiom checks.

The largest missing bridges are visible in `TARGETS.json`: infinitary Scott
theory and algebraic classification suppliers; effective ranked-tree ideal decomposition and Parikh/Presburger decision
suppliers; full MRDP; typed path-order and ordinal-analysis suppliers;
Snyatkov's arithmetic theorem; source-realization/undecidability suppliers;
Gorbow syntax, diagonalization and Löb; exact runtime/jump classifications;
and the actual analytic/probabilistic/algebraic semantics of the new papers.
They are not supplied as assumptions in the formal target register.
