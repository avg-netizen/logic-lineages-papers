# Current correction: Codex-only work; no Claude continuation

The user clarified: “I didn't ask you to involve Claude in the current lanes.”
The coordination thread incorrectly treated selection of the existing math
conversation as authorization to restore its historical Sol-supervises-Claude
workflow. That inference is revoked. Do not cite the November 7 release as
current authorization to launch Claude, resume its session, or wait for its quota.

Current work is Codex/Sol-only. Keep the existing mathematical scope, frozen
targets, exact statement/axiom checks and resource bounds; this correction does
not authorize unrelated proof searches, publication, another author or additional
workers. Reuse the existing Sol agent when its stalled turn is recovered. Do not
make a Claude launch, Claude output or an outbound status message a prerequisite
for current Codex work.

The historical Claude subject's AUTHOR-PAUSE, AUTHORIZATION and STATE controls
were snapshotted, then its author admission and automatic successor/quota resume
were disabled. These guards apply to the Claude runner; they do not constitute
a user request to pause the current Codex research. A delayed approval of the
old launch must not be treated as new user authorization or a reason to undo them.

R031 remains a prepared, target-only-compiled draft with no Claude author result.
R030's accepted proofs and all R031 source/target files are preserved. No theorem
acceptance or mathematical progress follows from this correction.

Both existing math conversation turns were previously marked waitingOnApproval:
the coordinator at an outbound status message, the Sol agent at an escalated
Claude launch. The available cross-thread tools can send messages but cannot
cancel those pending calls. Recover those turns through supported application
controls if needed; do not edit the application's SQLite state or weaken its
approval policy. Do not launch a duplicate worker to conceal the stall.

Private evidence: `projects/inverse/logic-lineages/notes/formalization-one-lane-2026-11-07/NO-CLAUDE-CORRECTION.json`.
