# Resume the single supervised formalization lane

**Superseded by user clarification, 8 November 2026 UTC.** The user did not ask
for Claude in the current lanes. The coordinator incorrectly inferred the
historical Claude workflow from selection of this conversation. Read
[the current Codex-only correction](CURRENT-2026-11-08-CODEX-ONLY.md).
The release below is history, not current author authorization.

The user explicitly selected this math thread for continuation alongside
separate prose research on 7 November 2026. Resume the existing single
GPT-6.1 Sol/xhigh supervisor **subagent**, with the same Claude author session.
This is a continuation of the post-R030 formalization work, not a new research
objective. The completed pause/no-R031 ceiling is superseded for this lane
only. All five independent math lanes and other Claude subjects stay paused.

## Baseline and next work

The local checkout is the published checkpoint
`9b4e9c32974306eaf8da2a3f67c937ad4fa936d8` on
`formalization/reconcile-unpublished-2026-11-04`. The tracked worktree was clean
and all three shared author/compiler locks were free at coordinator preflight.
Preserve the existing local unaccepted drafts and all historical receipts.
Read the [post-R030 handoff](HANDOFF-2026-11-04-ONE-LANE-PAUSED.md), R030 exact
acceptance/feedback and current runtime guards before changing any admission.

R030 proved the three quantified PA addition laws and their conjunction.
The original full R029 primitive-recursion numeral-certificate endpoint remains
pending. Select the next concrete source-preserving arithmetic/beta-trace
supplier from its actual unpaid dependencies, using R030's paid laws. Begin
with R031 after verifying all required previous-checkpoint pins. Do not rename
a smaller supplier as the full endpoint, or promote a numbered statement
without its entire mathematical dependency chain.

Sol must freeze definitions and exact comparison types and obtain a successful
target-only preflight before Claude authors each target. Compile candidates
first, constructively repair diagnostics without weakening the target, then
check the frozen exact type and actual transitive axioms. No sorry, admit,
native_decide, new axioms or hidden theorem premises. Only propext,
Classical.choice and Quot.sound are allowed axiom dependencies. A no-module
return may complete a truthfully unsuccessful review disposition; it never
counts as theorem acceptance.

## Runtime and coordination

Reuse `/root/claude_supervisor`, not a separate Codex task or additional worker.
Keep session `ac0922e0-cd7e-4974-8079-7a9c70779735`, Claude Opus5.5/high and
Read,Glob,Grep through the existing reviewed
`FORMALIZATION-2026-10-31/run_round.py`. Verify actual process/lock state and
checkpoint pins, then snapshot the completed pause/admission controls before
releasing only this subject and its shared compiler policy. Do not duplicate
a live author or compiler. Report actual initialization/source reads or a
concrete failure before claiming the author is working.

The sole supervisor holds the serialized compiler slot for its lane. Use only
`scripts/check.py`, both existing locks, one worker, 2048 MiB heap, 1536 MiB
RSS, 2048 MiB available-memory admission, 90 CPU and 180 wall seconds per
module. Keep Claude's 512 MiB observed RSS cap and existing read-only overlap
admission. No cold upstream rebuild or increased limits. On usage limits,
finish an already-returned candidate's repairs/checks/feedback, then wait for
the exact reset and resume the same session/pending round; no alternate author
or independent proof fallback during the wait.

Save release/runtime snapshots and concise progress in the private existing
project's `notes/formalization-one-lane-2026-11-07/`, and public proof evidence
in a matching `verification/` directory. Update the existing supervised task
and project from their current read revisions after concrete checkpoints.
Keep substantial proofs in their existing source homes. Continue coherent
supervised rounds until the user changes this release; a small checked supplier
is a checkpoint, not an automatic pause.

No new fetch, Git commit/push/merge, manuscript correction or dependency/CI
change is authorized. The prior publication permission was fulfilled by the
post-R030 push. Keep clear of the separate prose agents' directories:
`projects/slop/semantic-flow`, `projects/slop/judge-calibration`, and
`projects/weight-space-edit/2026-11-07-inquiry-retrieval`.

If the user requests another pause, disable successors immediately, finish only
the actual current round's finite closeout and preserve unresolved work as
unaccepted. Do not turn a stopping round into new suppliers or repeated repair
campaigns.
