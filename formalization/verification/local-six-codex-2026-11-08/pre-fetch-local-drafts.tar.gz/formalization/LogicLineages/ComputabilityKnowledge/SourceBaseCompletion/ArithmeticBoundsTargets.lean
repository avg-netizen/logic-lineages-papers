module

public import LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBoundsDefinitions
public import LogicLineages.ComputabilityKnowledge.GorbowTheoryProof

@[expose] public section
namespace LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds.Targets
open GorbowSyntax GorbowTheoryProof

def SumBound : Prop :=
  ∀ (T : Sentence → Prop) n c (x y : Term n),
    Nonempty (Derivation T (sumBoundFormula c x y))

def PositiveMultiplierBound : Prop :=
  ∀ (T : Sentence → Prop) n a M (q k : Term n),
    Nonempty (Derivation T (quotientBoundFormula a M q k))

def Target : Prop := SumBound ∧ PositiveMultiplierBound

end LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds.Targets
