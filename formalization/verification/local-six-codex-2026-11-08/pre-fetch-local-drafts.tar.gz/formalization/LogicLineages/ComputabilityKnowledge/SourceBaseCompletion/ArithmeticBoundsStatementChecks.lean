module

public import LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBoundsTargets
public import LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBoundsProof

@[expose] public section
namespace LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds.StatementChecks

theorem sumBound : Targets.SumBound := Proof.sumBound
theorem positiveMultiplierBound : Targets.PositiveMultiplierBound := Proof.positiveMultiplierBound
theorem arithmeticBounds : Targets.Target := Proof.fullTarget

#print axioms sumBound
#print axioms positiveMultiplierBound
#print axioms arithmeticBounds

end LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds.StatementChecks
