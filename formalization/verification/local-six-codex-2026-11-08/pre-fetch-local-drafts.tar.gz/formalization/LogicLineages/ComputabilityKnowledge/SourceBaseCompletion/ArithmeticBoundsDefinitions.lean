module

public import LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.BoundedRangeDefinitions
public import LogicLineages.ComputabilityKnowledge.GorbowStandardInstances

@[expose] public section
/-! Literal compiler bounds at arbitrary full-language terms. The arithmetic
formulas below are proof obligations in the existing PA calculus, not axioms.
The multiplier is a fixed positive numeral; zero is never included. -/
namespace LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds
open GorbowSyntax

/-- Specialize the actual paid compiler guard, retaining every other parameter. -/
def boundAt {n : Nat} (bound : Nat) (x : Term n) : Formula n :=
  GorbowStandardInstances.instantiate (BoundedRange.guard (m := n) bound) x

def sumBoundFormula {n : Nat} (c : Nat) (x y : Term n) : Formula n :=
  .imp (.equal (.add x y) (Term.numeral c)) (boundAt (c+1) x)

/-- The coefficient is the positive numeral M+1; q and k are arbitrary terms. -/
def quotientBoundFormula {n : Nat} (a M : Nat) (q k : Term n) : Formula n :=
  .imp (.equal (.add (.mul q (Term.numeral (M+1))) k) (Term.numeral a))
    (boundAt (a+1) q)

end LogicLineages.ComputabilityKnowledge.SourceBaseCompletion.ArithmeticBounds
