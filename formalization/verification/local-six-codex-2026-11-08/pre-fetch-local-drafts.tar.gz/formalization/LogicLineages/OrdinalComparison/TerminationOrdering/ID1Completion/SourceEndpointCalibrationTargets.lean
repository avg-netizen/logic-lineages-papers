module
public import LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.SourceEndpointDefinitions
@[expose] public section
namespace LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.SourceEndpointCalibrationTargets
open Source PositiveArithmeticOperators PositiveArithmeticTransforms
open ID1Completion.InternalCalculus ID1Completion.SourceEndpoint

/-- The actual one-operator calculus body, after the source window has been
closed to a numeral, retains EXACTLY the original R/DM(R) successors. -/
def ActualClosedSourceOperator : Prop :=
  ∀ (n : Nat) (arity : Fin n → Nat) (Gamma : List Ty)
    (context : Nat) (P : Nat → Prop) (x : Nat),
  (realize P (sourceBody n arity Gamma context).formula ![tagNumber false x] ↔
    OrdinaryArithmeticCarrier.encodedScalar n arity Gamma context x ∧
      ∀ y, encodedR n arity Gamma context x y → P (tagNumber false y)) ∧
  (realize P (sourceBody n arity Gamma context).formula ![tagNumber true x] ↔
    OrdinaryArithmeticCarrier.encodedList n arity Gamma context x ∧
      ∀ y, OrdinaryArithmeticDirect.encodedDirect n arity Gamma context x y → P (tagNumber true y))

/-- The entire pending first-order theorem says all canonical typed source
terms belong to I. There is no hidden syntactic-fragment antecedent. -/
def ActualAllTermsFormulaTruth : Prop :=
  ∀ (n : Nat) (arity : Fin n → Nat) (Gamma : List Ty)
    (context : Nat) (P : Nat → Prop),
  realize P (allTermsFormula n arity Gamma context) Empty.elim ↔
    ∀ x, OrdinaryArithmeticCarrier.encodedScalar n arity Gamma context x → P (tagNumber false x)

/-- Enforces the source interpretation of a future proof: a proof tree of
the frozen closed theorem yields accessibility under ORIGINAL positive R.
This soundness consumer does not assert that the proof tree exists. -/
def ActualInternalSourceSoundness : Prop :=
  ∀ (n : Nat) (arity : Fin n → Nat) (Gamma : List Ty)
    (symbols : List (Fin n)) (S : List Ty) (table : Fin n → Fin n → Bool),
  SubtypeClosed (fun tau => tau ∈ S) →
  Nonempty (Derivation
    (sourceBody n arity Gamma (OrdinaryArithmeticQuotient.contextCode symbols S table)) []
    (allTermsFormula n arity Gamma (OrdinaryArithmeticQuotient.contextCode symbols S table))) →
  ∀ x, OrdinaryArithmeticCarrier.encodedScalar n arity Gamma
      (OrdinaryArithmeticQuotient.contextCode symbols S table) x →
    Acc (fun successor source => encodedR n arity Gamma
      (OrdinaryArithmeticQuotient.contextCode symbols S table) source successor) x

end LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.SourceEndpointCalibrationTargets
