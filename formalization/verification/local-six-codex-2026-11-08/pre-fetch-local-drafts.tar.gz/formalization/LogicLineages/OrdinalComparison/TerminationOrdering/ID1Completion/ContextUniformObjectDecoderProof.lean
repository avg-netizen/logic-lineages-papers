module
public import LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.ContextUniformQuotientTargets
public import LogicLineages.OrdinalComparison.TerminationOrdering.OrdinaryArithmeticQuotientDecoderProof
public import LogicLineages.OrdinalComparison.TerminationOrdering.NumberedQuotientPathPrimrecSupportProof
@[expose] public section
namespace LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.ContextUniformObjectDecoderProof
open Source ContextUniformQuotient

attribute [local irreducible] Primrec

theorem objectDecoderPrimitive : Primrec (Encodable.decode : Nat → Option ContextUniform.Object) := by
  apply (Primrec.decode (α := ContextUniform.Object)).of_eq
  intro value
  with_reducible_and_instances rfl

theorem decodedUnaryPrimitive (n : Nat)
    (f : OrdinaryArithmeticQuotient.Context n × ContextUniform.Object → Bool) (hf : Primrec f) :
    Primrec (fun v : List.Vector Nat 2 =>
      ((Encodable.decode (α := OrdinaryArithmeticQuotient.Context n) (v.get 0)).any (fun ctx =>
        (Encodable.decode (α := ContextUniform.Object) (v.get 1)).any (fun obj => f (ctx,obj)))).toNat) := by
  have getP (i : Fin 2) : Primrec (fun v : List.Vector Nat 2 => v.get i) :=
    Primrec.vector_get.comp Primrec.id (Primrec.const i)
  have hctx := (OrdinaryArithmeticQuotientDecoderProof.contextDecoderPrimitive n).comp (getP 0)
  have hobj : Primrec (fun p : List.Vector Nat 2 × OrdinaryArithmeticQuotient.Context n =>
      Encodable.decode (α := ContextUniform.Object) (p.1.get 1)) :=
    objectDecoderPrimitive.comp ((getP 1).comp Primrec.fst)
  have hb : Primrec (fun p : (List.Vector Nat 2 × OrdinaryArithmeticQuotient.Context n) × ContextUniform.Object =>
      f (p.1.2,p.2)) := hf.comp ((Primrec.snd.comp Primrec.fst).pair Primrec.snd)
  have hi := NumberedQuotientPathPrimrecSupportProof.optionAnyPrimitive hobj hb.to₂
  exact ((Primrec.dom_bool Bool.toNat).comp
    (NumberedQuotientPathPrimrecSupportProof.optionAnyPrimitive hctx hi.to₂)).of_eq (by intro v; rfl)

theorem decodedBinaryPrimitive (n : Nat)
    (f : Parameters n × Nat × Nat × Nat → Bool) (hf : Primrec f) :
    Primrec (fun v : List.Vector Nat 4 =>
      ((Encodable.decode (α := OrdinaryArithmeticQuotient.Context n) (v.get 0)).any (fun ctx =>
        (Encodable.decode (α := ContextUniform.Object) (v.get 1)).any (fun source =>
          (Encodable.decode (α := ContextUniform.Object) (v.get 2)).any (fun target =>
            decide (source.1=target.1) &&
              f (((ctx.1,source.1),ctx.2),source.2,target.2,v.get 3))))).toNat) := by
  let Input := ((List.Vector Nat 4 × OrdinaryArithmeticQuotient.Context n) × ContextUniform.Object) × ContextUniform.Object
  have getP (i : Fin 4) : Primrec (fun v : List.Vector Nat 4 => v.get i) :=
    Primrec.vector_get.comp Primrec.id (Primrec.const i)
  have hctx : Primrec (fun p : Input => p.1.1.2) := Primrec.snd.comp (Primrec.fst.comp Primrec.fst)
  have hsource : Primrec (fun p : Input => p.1.2) := Primrec.snd.comp Primrec.fst
  have hg := Primrec.fst.comp hsource
  have hparams := ((Primrec.fst.comp hctx).pair hg).pair (Primrec.snd.comp hctx)
  have hvec : Primrec (fun p : Input => p.1.1.1) := Primrec.fst.comp (Primrec.fst.comp Primrec.fst)
  have hbody := hf.comp (hparams.pair ((Primrec.snd.comp hsource).pair
    ((Primrec.snd.comp Primrec.snd).pair ((getP 3).comp hvec))))
  have hguard := (Primrec.eq.comp hg (Primrec.fst.comp Primrec.snd)).decide
  have hchecked := Primrec.and.comp hguard hbody
  have htarget : Primrec (fun p : (List.Vector Nat 4 × OrdinaryArithmeticQuotient.Context n) × ContextUniform.Object =>
      Encodable.decode (α := ContextUniform.Object) (p.1.1.get 2)) :=
    objectDecoderPrimitive.comp ((getP 2).comp (Primrec.fst.comp Primrec.fst))
  have hi := NumberedQuotientPathPrimrecSupportProof.optionAnyPrimitive htarget hchecked.to₂
  have hsourceDecode : Primrec (fun p : List.Vector Nat 4 × OrdinaryArithmeticQuotient.Context n =>
      Encodable.decode (α := ContextUniform.Object) (p.1.get 1)) :=
    objectDecoderPrimitive.comp ((getP 1).comp Primrec.fst)
  have hs := NumberedQuotientPathPrimrecSupportProof.optionAnyPrimitive hsourceDecode hi.to₂
  have hc := (OrdinaryArithmeticQuotientDecoderProof.contextDecoderPrimitive n).comp (getP 0)
  exact ((Primrec.dom_bool Bool.toNat).comp
    (NumberedQuotientPathPrimrecSupportProof.optionAnyPrimitive hc hs.to₂)).of_eq (by intro v; rfl)

end LogicLineages.OrdinalComparison.TerminationOrdering.ID1Completion.ContextUniformObjectDecoderProof
